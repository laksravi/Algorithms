package homework4;

import java.util.Scanner;

public class Partitions {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int numInputs = sc.nextInt();
		int[] inputArray = new int[numInputs];
		int sum = 0;

		for (int index = 0; index < numInputs; index++) {
			inputArray[index] = sc.nextInt();
			sum = sum + inputArray[index];
		}

		int numPossibleSets = 0;
		int oddCount = 0;
		int[] oddEvenArray = new int[numInputs];

		// deciding odd and even array elements
		for (int index = 0; index < numInputs; index++) {
			oddEvenArray[index] = inputArray[index] % 2;
		}

		// Printing odd and even array
		/*
		 * for (int index = 0; index < numInputs; index++) {
		 * System.out.print(oddEvenArray[index] + "   "); }
		 */
		// building array of odd numbers count till i'th index
		for (int index = 0; index < numInputs; index++) {
			// Odd number found
			if (oddEvenArray[index] == 1) {
				oddCount += 1;
				oddEvenArray[index] = oddCount;
			} else {
				// Even number found
				if (index != 0) {
					oddEvenArray[index] = oddEvenArray[index - 1];
				} else {
					oddEvenArray[index] = 0;
				}
			}
		}

		boolean startPoint = false;
		for (int index = 0; index < numInputs; index++) {
			// Odd + Odd = Even, Occurrence of odd elements even number of times
			// makes Sum even
			if (oddEvenArray[index] % 2 == 0) {
				if (!startPoint) {
					numPossibleSets = 1;
					startPoint = true;
				} else {
					numPossibleSets = numPossibleSets * 2;
				}
			}

		}

		System.out.println(numPossibleSets);

	}

}
